<?php	
$koneksi = new mysqli("localhost", "root", "", "bpsdmdjateng_simonika");