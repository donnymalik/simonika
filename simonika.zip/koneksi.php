<?php	
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "bpsdmdjateng_simonika";

	$conn = mysqli_connect($servername, $username, $password, $dbname) or die("Connection failed: " . mysqli_connect_error());
