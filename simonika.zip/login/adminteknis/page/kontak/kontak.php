<div class="footer-above">
    <div class="container">
        <div class="row">
            <div class="footer-col col-md-3">
                <h3>Lokasi</h3>
                <p>Jalan Setiabudi No. 201 A Semarang
                    <br>Kode Pos : 50263</p>
            </div>
            <div class="footer-col col-md-3">
                <h3>Media Sosial</h3>
                <ul class="list-inline">
                    <li>
                        <a href="https://facebook.com/bpsdmdjtg" target="_blank" class="btn-social btn-outline"><span class="sr-only">Facebook</span><i class="fa fa-fw fa-facebook"></i></a>
                    </li>
                    <li>
                        <a href="https://twitter.com/bpsdmdjtg" target="_blank" class="btn-social btn-outline"><span class="sr-only">Twitter</span><i class="fa fa-fw fa-twitter"></i></a>
                    </li>
                    <li>
                        <a href="https://www.instagram.com/bpsdmdjtg/" target="_blank" class="btn-social btn-outline"><span class="sr-only">Dribble</span><i class="fa fa-fw fa-instagram"></i></a>
                    </li>
                </ul>
            </div>
            <div class="footer-col col-md-3">
                <h3>Kontak</h3>
                <p>Telp. 7473066 Fax. 7473701 Email : bpsdmd@jatengprov.go.id</a>.</p>
            </div>
        </div>
    </div>
</div>
<div class="footer-below">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                Copyright &copy; BPSDMD Provinsi Jawa Tengah
            </div>
        </div>
    </div>
</div>
