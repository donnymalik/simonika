<?php
session_start();
$_SESSION['nama'] = null;
header("Location: ../../"); // Langsung mengarah ke Home index.php